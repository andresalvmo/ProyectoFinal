module Proyecto.Final {
    requires javafx.graphics;
    requires javafx.controls;
    requires javafx.fxml;
    requires org.junit.jupiter.api;

    opens sample;
}