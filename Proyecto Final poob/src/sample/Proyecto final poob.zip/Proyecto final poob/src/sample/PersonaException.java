package sample;

public class PersonaException {
}
